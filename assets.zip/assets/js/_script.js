$(document).ready(function()
{
	function checkLogin()
	{
		debugger;
		let islogin=localStorage.getItem("userLogin");
		
		if(isLogin==="true")
		{
			$("#grades").removeClass("disabled");
			$("#grades").addClass("enabled");
		}
		else
		{
			$("#grades").addClass("disabled");
		}
		
	}
	checkLogin();
$("#form").validate({
      rules: {
        firstname:
		{ 
			required:true
		},
        lastname: 
		{
          required: true
        },
        email: {
          required: true,
          email: true
        },
        mypassword: 
		{
          required: true,
		  minlength:6
        },
		userage:
		{
			required:true
			/*valueNotEquals: "default"*/
		}
		
      },
      messages: {
        firstname: "Firstname is required.",
        lastname: "Lasttname is required.",
        email: {
          required: "Email address is required",
          email: "Email address must be in the format of abc@domain.com"
        },
		mypassword:
		{
			required: "Password is required",
			minLength:"Password must be at least 6 characters long"
		}
      }
    });	

	var userObj=null;
	var text = { 
				user : []
				};
	var myrelation="";
	var myage="";
	const formsubmitted=null;
	$('#form').submit(function(event)
	{
		event.preventDefault();
		
		userObj=localStorage.getItem("userJson");	
	
		if(userObj!==null)
		{
			text=JSON.parse(userObj);
		}
		debugger;
		text.user.push({"firstname" : $("#firstname").val(),
		"lastname":$("#lastname").val(),
		"mypassword":$("#mypassword").val(),
		"email":$("#email").val()
		/*"userage":($("#userage").val()=="default")?"5":($("#userage").val())*/
		});
		
		text=JSON.stringify(text);
		localStorage.removeItem("userJson");
		localStorage.setItem("userJson", text);
		
	});
	
	



	
/*Login Start*/
/*Login Validate start*/

$("#formlogin").validate({
      rules: {
        emaillogin: {
          required: true,
          email: true
        },
		mypasswordlogin: 
		{
          required: true,
        }
		
      },
      messages: {
        emaillogin: {
          required: "Please Enter Email Address for Login",
          email: "Email address must be in the format of abc@domain.com"
        },
		mypasswordlogin:
		{
			required: "Please Enter Password"
		},
      }
    });	
/* Login Vaidate end*/
$('#formlogin').submit(function(event)
{	
	event.preventDefault();	
	userObj=localStorage.getItem("userJson");	
		
	if(userObj!==null)
	{
		text=JSON.parse(userObj);
	}
	let a=$("#emaillogin").val();
	let b= $("#mypasswordlogin").val();
	debugger;
	$.each(text.user, function( index, value ) {
		if($("#emaillogin").val() == value.email)
		{
			if($("#mypasswordlogin").val() == value.mypassword)
			{
				debugger;
				alert("User Exist");
				localStorage.setItem("userLogin", "true");
				$("#grades").removeClass("disabled");
				$("#grades").addClass("enabled");
			}
		}
	
	});	
});

/* Login End*/
	
/*Contact Us Start*/
$("#formcontactus").validate({
  rules: {
	firstnamecontactus:
	{ 
		required:true
	},
	lastnamecontactus: 
	{
	  required: true
	},
	emailcontactus: {
	  required: true,
	  email: true
	},
	 commentcontactus: 
	{
	  required: true
	},
	
  },
  messages: {
	firstnamecontactus: "Firstname is required.",
	lastnamecontactus: "Lasttname is required.",
	emailcontactus: {
	  required: "Email address is required",
	  email: "Email address must be in the format of abc@domain.com"
	},
	commentcontactus: {
	  required: "Comments are required"
	},
  }
});	
var userComment=null;
var allComments = { 
			comment : []
			};
var check=null;
$('#formcontactus').submit(function(event)
{	
	userComment=localStorage.getItem("userCommentJson");	

	if(userComment!==null)
	{
		allComments=JSON.parse(userComment);
	}
	
	allComments.comment.push({"firstnamecontactus" : $("#firstnamecontactus").val(),
	"lastnamecontactus":$("#lastnamecontactus").val(),
	
	"emailcontactus":$("#emailcontactus").val(),
	"commentcontactus":$("#commentcontactus").val()
	/*"userage":($("#userage").val()=="default")?"5":($("#userage").val())*/
	
	});
	
	allComments=JSON.stringify(allComments);
	localStorage.removeItem("userCommentJson");
	localStorage.setItem("userCommentJson", allComments);
});
/*Contact Us End*/

/*FAQ.html (accordion) start*/

$( "#accordion" ).accordion(
{
	collapsible :true
});

/*FAQ.html (accordion) End*/

/*Up Coming Events Start*/
$(".upcomingevents").slick(
{
	dots: true,
	slidesToShow: 1,
	slidesToScroll: 1,
	dots:false
  }
);
$("#testimonials").slick(
{
	dots: true,
	slidesToShow: 1,
	slidesToScroll: 1
  }
);
/*Up Coming Events End*/


/*light gallery*/

$('#lightgallery').lightGallery({
		pager: true
		});
		
		
/*social share*/
$('#share-bar').share();



});