$(document).ready(function()
{
	const lname = localStorage.getItem('userLogin');
	console.log(lname);
	debugger;
	if(lname != null)
		{
			$("#grades").removeClass("disabled");
			$("#grades").addClass("enabled");
			$( "li#login" ).addClass( "loginbtn-hide" );
			$( "li#login" ).removeClass( "border" );			
			$("li.userstaus").text("Welcome: "+ lname);
			$("li.userstaus").addClass("userstaus-show");
			$(".logout").addClass("logout-show");
			$(".logout").removeClass("logout-hide");
		}
		else
		{
			$("#grades").addClass("disabled");
			$(".logout").addClass("logout-hide");
			$(".logout").removeClass("logout-show");
		}
		var userObj=null;
	var text = { 
				user : []
				};
	
	const formsubmitted=null;
$("#form").validate({
      rules: {
        firstname:
		{ 
			required:true
		},
        lastname: 
		{
          required: true
        },
        email: {
          required: true,
          email: true
        },
        mypassword: 
		{
          required: true,
		  minlength:6
        },
		userage:
		{
			required:true
			/*valueNotEquals: "default"*/
		}
		
      },
      messages: {
        firstname: "Firstname is required.",
        lastname: "Lasttname is required.",
        email: {
          required: "Email address is required",
          email: "Email address must be in the format of abc@domain.com"
        },
		mypassword:
		{
			required: "Password is required",
			minLength:"Password must be at least 6 characters long"
		},
		userage:
		{
			required :  "Please select age"
			/*valueNotEquals: "Please select an item!"*/
        }
      },
	    submitHandler: function(form ) {
		  
		userObj=localStorage.getItem("userJson");	
		
			if(userObj!==null)
			{
				text=JSON.parse(userObj);
			}
			debugger;
			text.user.push({"firstname" : $("#firstname").val(),
			"lastname":$("#lastname").val(),
			"mypassword":$("#mypassword").val(),
			"email":$("#email").val()
			});
			
			text=JSON.stringify(text);
			localStorage.removeItem("userJson");
			localStorage.setItem("userJson", text);
			$("input:text").val("");
	  }
    });	

/*Login Start*/
/*Login Validate start*/

$("#formlogin").validate({
      rules: {
        emaillogin: {
          required: true,
          email: true
        },
		mypasswordlogin: 
		{
          required: true,
        }
		
      },
      messages: {
        emaillogin: {
          required: "Please Enter Email Address for Login",
          email: "Email address must be in the format of abc@domain.com"
        },
		mypasswordlogin:
		{
			required: "Please Enter Password"
		},
      },
	  submitHandler: function(form ) {
		 
		userObj=localStorage.getItem("userJson");	
		
		if(userObj!==null)
		{
			text=JSON.parse(userObj);
		}
		
		let isuser=false;
		
		$.each(text.user, function( index, value ) {
			
			if($("#emaillogin").val() == value.email)
			{
				if($("#mypasswordlogin").val() == value.mypassword)
				{
					
					localStorage.setItem("userLogin", value.firstname + " " + value.lastname);
					$("#grades").removeClass("disabled");
					$("#grades").addClass("enabled");
					debugger;
					
					
					$( "li#login" ).addClass( "loginbtn-hide" );
					$( "li#login" ).removeClass( "border" );
					$(".logout").addClass("logout-show");
					$(".logout").removeClass("logout-hide");
					
					
					
					$("li.userstaus").text("Welcome: "+value.firstname + " " + value.lastname);
					$("li.userstaus").addClass("userstaus-show");
					debugger;
					window.open("index.html");
					
					isuser=true;
				}
			}
	  });
	  }
    });	

/* Login Vaidate end*/
	
	/* Login End*/
	
	/*Contact Us Start*/
	var userComment=null;
	var allComments = { 
				comment : []
				};
	var check=null;
	
	$("#formcontactus").validate({
      rules: {
        firstnamecontactus:
		{ 
			required:true
		},
        lastnamecontactus: 
		{
          required: true
        },
        emailcontactus: {
          required: true,
          email: true
        },
         commentcontactus: 
		{
          required: true
        }
		
      },
      messages: {
        firstnamecontactus: "Firstname is required.",
        lastnamecontactus: "Lasttname is required.",
        emailcontactus: {
          required: "Email address is required",
          email: "Email address must be in the format of abc@domain.com"
        },
		commentcontactus: {
          required: "Comments are required"
        }
      },
	  submitHandler: function(form) {
		  
		userComment=localStorage.getItem("userCommentJson");	
		
			if(userComment!==null)
			{
				allComments=JSON.parse(userComment);
			}
			
			allComments.comment.push({"firstnamecontactus" : $("#firstnamecontactus").val(),
			"lastnamecontactus":$("#lastnamecontactus").val(),
			
			"emailcontactus":$("#emailcontactus").val(),
			"commentcontactus":$("#commentcontactus").val()
			/*"userage":($("#userage").val()=="default")?"5":($("#userage").val())*/
			
			});
			
			allComments=JSON.stringify(allComments);
			localStorage.removeItem("userCommentJson");
			localStorage.setItem("userCommentJson", allComments);  
		  
		form.submit();
	  }
    });	
	
	/*Contact Us End*/

/*worksheet start*/



/*worksheet end*/


	/*FAQ.html (accordion) start*/
	
	$( "#accordion" ).accordion(
	{
		collapsible :true
	});
	
	/*FAQ.html (accordion) start*/
	
	/*Up Coming Events Start*/
	$(".upcomingevents").slick(
	{
        dots: true,
        slidesToShow: 1,
        slidesToScroll: 1,
		dots:false
      }
	);
	$("#testimonials").slick(
	{
        dots: true,
        slidesToShow: 1,
        slidesToScroll: 1
      }
	);
	/*Up Coming Events End*/
	
	
	/*light gallery*/
	
	$('#lightgallery').lightGallery({
            pager: true
            });
			
			
	/*social share*/
	$('#share-bar').share();
	

	/*function stringToBoolean(string)
	{
			switch(string.toLowerCase().trim()){
				case "true": case "yes": case "1": return true;
				case "false": case "no": case "0": case null: return false;
				default: return Boolean(string);
		}
	}
	function checkLogin()
	{
		debugger;
		let islogin=localStorage.getItem("userLogin");
		islogin= stringToBoolean(islogin);
		if(islogin)
		{
			$("#grades").removeClass("disabled");
			$("#grades").addClass("enabled");
		}
		else
		{
			$("#grades").addClass("disabled");
		}
		
	}

	// checkLogin();*/
	$(".logout").click(function(){
		localStorage.removeItem('userLogin');
		$(".logout").addClass("logout-hide");
		$(".logout").removeClass("logout-show");
		$("#grades").removeClass("enabled");
		$("#grades").addClass("disabled");
		$("li.userstaus").addClass("userstaus-hide");
		$("li.userstaus").removeClass("userstaus-show");
		$( "li#login" ).removeClass( "loginbtn-hide" );
		$( "li#login" ).addClass( "loginbtn-show" );
		$( "li#login" ).addClass( "border" );
		
  });
});